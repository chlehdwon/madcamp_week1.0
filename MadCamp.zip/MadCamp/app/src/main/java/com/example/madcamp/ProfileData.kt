package com.example.madcamp

data class ProfileData (
    val name : String,
    val age : Int
)